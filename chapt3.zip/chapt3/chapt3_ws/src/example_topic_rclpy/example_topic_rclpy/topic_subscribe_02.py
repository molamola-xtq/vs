#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

from std_msgs.msg import String


class NodeSubscribe02(Node):
    def __init__(self,name):
        super().__init__(name)
        self.get_logger().info("大家好，我是%s!" % name)
        # 创建订阅者
        self.command_subscribe_ = self.create_subscription(String,"command",self.command_callback,10)

    def command_callback(self,msg):
        strr =  msg.data
        l = strr.split(" ");
        order = ''
        x1 = 0
        x2 = 0
        y1 = 0
        y2 = 0
        if(l[0] != 'bottle'):
            order = "错误识别"
        else :
            x1 = float(l[3])
            y1 = float(l[4])
            x2 = float(l[5])
            y2 = float(l[6])
            f = []
            for i in l[2]:
                if(i!='m'):
                    f.append(i)
            dis = "".join(f)
            distance = float(dis)
            order = "成功识别"
         

        self.get_logger().info(f'左上角坐标:（{l[3]},{l[4]}）,右下角坐标:({l[5]},{l[6]}),距离:{distance}m')


def main(args=None):
    rclpy.init(args=args) # 初始化rclpy
    node = NodeSubscribe02("topic_subscribe_02")  # 新建一个节点
    rclpy.spin(node) # 保持节点运行，检测是否收到退出指令（Ctrl+C）
    rclpy.shutdown() # 关闭rclpy
